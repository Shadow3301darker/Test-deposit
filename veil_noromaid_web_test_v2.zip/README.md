# VEIL GGUF Web Test v2

The first prototype successfully proved:
- WebGPU adapter works on the iPad.
- The GGUF loads locally.
- The runtime initializes.

The failure happened only when `createChatCompletion()` entered `formatChat()`. This version deliberately uses `createCompletion()` (raw text completion), which bypasses chat-template formatting. Once raw generation works, we can add the correct chat template/configuration for the target model.

Upload only `index.html` to the GitHub Pages repo. Do not upload the model.
